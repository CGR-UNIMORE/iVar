openssl req -new -newkey rsa:2048 -subj "/CN=iVar/OU=FakeCA/OU=DefaultDemoCert" -out ca-ivar-certrequest.pem
mv privkey.pem ca-ivar-privkey.pem
# firma la CA
openssl x509 -req -in ca-ivar-certrequest.pem -out ca-ivar-cert.pem -CAkey ca-ivar-privkey.pem -signkey ca-ivar-privkey.pem -days 7298 -set_serial 1
