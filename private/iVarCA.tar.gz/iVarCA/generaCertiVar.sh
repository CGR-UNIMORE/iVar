# richiedo il cert 
openssl req -new -newkey rsa:2048 -subj "/CN=ivar.local" -out ivar-certrequest.pem
echo "Approvalo";
# Approvo il certificato 
openssl x509 -req -in ivar-certrequest.pem -out ivar-cert.pem -CAkey ca-ivar-privkey.pem -CA ca-ivar-cert.pem -days 7297 -set_serial 202 -extfile server-ivar.ext
# ci tolgo la passphrase
echo "Tolgo la passphrase";
openssl rsa -in privkey.pem -out ivar-privkey.pem
